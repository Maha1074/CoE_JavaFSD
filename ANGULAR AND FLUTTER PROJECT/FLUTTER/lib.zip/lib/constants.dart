import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xff2B475E);
const kLogo = 'assets/images/scholar.png';
const kMessagesCollections = 'messages';
const kMessage = 'message';
const kCreatedAt = 'createdAt';
