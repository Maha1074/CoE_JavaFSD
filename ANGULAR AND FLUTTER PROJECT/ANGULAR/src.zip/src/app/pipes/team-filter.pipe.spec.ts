import { TeamFilterPipe } from './team-filter.pipe';

describe('TeamFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TeamFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
