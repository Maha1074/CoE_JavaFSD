import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'teamFilter',
  standalone: true 
})
export class TeamFilterPipe implements PipeTransform {
  transform(teams: any[], searchTerm: string): any[] {
    if (!teams || !searchTerm) return teams;
    return teams.filter(team =>
      team.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }
}
