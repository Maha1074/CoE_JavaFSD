import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-response',
  standalone: true,
  imports: [CommonModule], // ✅ Required for *ngIf, *ngFor
  templateUrl: './response.component.html',
  styleUrls: ['./response.component.css']
})
export class ResponseComponent {
  responses: any[] = [];

  ngOnInit() {
    const storedResponses = localStorage.getItem('responses');
    if (storedResponses) {
      this.responses = JSON.parse(storedResponses);
    }
  }
}
