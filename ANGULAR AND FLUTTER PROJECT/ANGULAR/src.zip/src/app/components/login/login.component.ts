import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, FormsModule]
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  errorMessage: string = '';
  isLoggedIn: boolean = false;
  isBrowser: boolean = false;
  contactResponses: any[] = [];

  constructor(private router: Router, @Inject(PLATFORM_ID) private platformId: Object) {
    this.isBrowser = isPlatformBrowser(platformId);

    if (this.isBrowser) {
      const loggedInStatus = localStorage.getItem('isAdminLoggedIn');
      this.isLoggedIn = loggedInStatus === 'true';

      if (this.isLoggedIn) {
        this.loadResponses();
      }
    }
  }

  onLogin() {
    if (this.email === 'abc123@gmail.com' && this.password === 'admin123') {
      if (this.isBrowser) {
        localStorage.setItem('isAdminLoggedIn', 'true');
        this.loadResponses();
      }
      this.isLoggedIn = true;
      this.errorMessage = '';
    } else {
      this.errorMessage = 'Invalid credentials. Try again.';
    }
  }

  onLogout() {
    if (this.isBrowser) {
      localStorage.removeItem('isAdminLoggedIn');
    }
    this.isLoggedIn = false;
    this.email = '';
    this.password = '';
    this.contactResponses = [];
  }

  loadResponses() {
    if (this.isBrowser) {
      const storedResponses = localStorage.getItem('responses');
      const allResponses = storedResponses ? JSON.parse(storedResponses) : [];

      // Keep only the latest submission
      this.contactResponses = allResponses.length ? [allResponses[allResponses.length - 1]] : [];

      // Update localStorage to store only the latest response
      localStorage.setItem('responses', JSON.stringify(this.contactResponses));
    }
  }
}
