import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { TeamService } from '../../services/team.service';
import { TeamFilterPipe } from '../../pipes/team-filter.pipe';

@Component({
  standalone: true,
  selector: 'app-teams',
  templateUrl: './teams.component.html',
  styleUrls: ['./teams.component.css'],
  imports: [CommonModule, RouterModule, FormsModule, TeamFilterPipe]
})
export class TeamsComponent implements OnInit {
  teams: any[] = [];
  searchTerm: string = '';

  constructor(private teamService: TeamService) {}

  ngOnInit() {
    this.fetchTeams();
  }

  fetchTeams() {
    this.teamService.getTeams().subscribe({
      next: (data) => {
        this.teams = data;
      },
      error: (err) => {
        console.error('Error fetching teams:', err);
      }
    });
  }
}
