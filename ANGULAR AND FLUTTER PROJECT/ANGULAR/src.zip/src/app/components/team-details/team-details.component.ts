import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import teamPlayersData from '../../../../teams.json'; // ✅ Make sure this path is correct
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-team-detail',
  templateUrl: './team-details.component.html',
  styleUrls: ['./team-details.component.css'],
  standalone: true,
  imports: [CommonModule, NgFor]  // ✅ Removed NgIf warning
})
export class TeamDetailComponent implements OnInit {
  teamId: number = 0;
  players: any[] = [];
  teamName: string = '';

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const idParam = params.get('id');
      this.teamId = idParam ? +idParam : 0;

      const teams = teamPlayersData.teams;
      const team = teams.find((t: any) => t.id === this.teamId);

      if (team && team.players) {
        this.players = team.players;
        this.teamName = team.name;
      }
    });
  }
}
