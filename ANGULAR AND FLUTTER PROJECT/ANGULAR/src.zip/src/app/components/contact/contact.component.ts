import { Component, Inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-contact',
  standalone: true,
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css'],
  imports: [FormsModule]
})
export class ContactComponent {
  contact = { name: '', email: '', message: '' };
  responses: any[] = [];

  constructor(private router: Router, @Inject(PLATFORM_ID) private platformId: Object) {
    if (isPlatformBrowser(this.platformId)) {
      const storedResponses = localStorage.getItem('responses');
      this.responses = storedResponses ? JSON.parse(storedResponses) : [];
    }
  }

  onSubmit() {
    // Validate: prevent blank submissions
    if (!this.contact.name.trim() || !this.contact.email.trim() || !this.contact.message.trim()) {
      alert('Please fill in all fields before submitting.');
      return;
    }

    this.responses.push({ ...this.contact });

    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('responses', JSON.stringify(this.responses));
    }

    alert('Form submitted! ✅');
    this.contact = { name: '', email: '', message: '' };
    this.router.navigate(['/teams']);
  }
}
