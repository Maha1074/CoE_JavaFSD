import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';

// ✅ Standalone components
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { TeamsComponent } from './components/teams/teams.component';
import { TeamDetailComponent } from './components/team-details/team-details.component';
import { ContactComponent } from './components/contact/contact.component';
import { ResponseComponent } from './components/response/response.component';
import { LoginComponent } from './components/login/login.component';

// ✅ Standalone pipe
import { TeamFilterPipe } from './pipes/team-filter.pipe';

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule,

    // ✅ Standalone components and pipes
    HomeComponent,
    AboutComponent,
    TeamsComponent,
    TeamDetailComponent,
    ContactComponent,
    ResponseComponent,
    LoginComponent,
    TeamFilterPipe
  ],
  declarations: [
    AppComponent
    // ❌ DO NOT add standalone components here
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
